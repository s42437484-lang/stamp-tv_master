package com.lagradost.cloudstream3.utils

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.lagradost.cloudstream3.CommonActivity.showToast
import com.lagradost.cloudstream3.R
import com.lagradost.cloudstream3.databinding.DialogAppIconPickerBinding
import com.lagradost.cloudstream3.databinding.ItemAppIconBinding

/**
 * Lets the user pick the launcher icon.
 *
 * How it works: AndroidManifest.xml has one <activity-alias> per icon (all pointing at the real
 * launcher activity). Only one alias is enabled at a time, switching icons just enables the chosen
 * alias and disables the others with PackageManager.
 *
 * ADDING AN ICON:
 *  1. Add a new <activity-alias> in AndroidManifest.xml (copy one of the .alias.Icon... blocks)
 *  2. Add its adaptive icon in res/mipmap-anydpi-v26/ic_launcher_<id>.xml (+ the same name in
 *     res/mipmap-anydpi-v21/ for Android 5-7) and a foreground drawable ic_app_icon_<id>
 *  3. Add a new [AppIconOption] to [options] below.
 *
 * The [aliasName] must match the android:name of the alias (without the leading ".alias.").
 */
object AppIconUtils {
    private const val TAG = "AppIconUtils"
    private const val ALIAS_PACKAGE = "com.lagradost.cloudstream3.alias."

    data class AppIconOption(
        val id: String,
        @StringRes val label: Int,
        val aliasName: String,
        @ColorRes val background: Int,
        @DrawableRes val foreground: Int,
        /** Must match android:enabled of the alias in the manifest */
        val enabledByDefault: Boolean = false,
    )

    val options: List<AppIconOption> = listOf(
        AppIconOption(
            id = "default",
            label = R.string.app_icon_default,
            aliasName = "IconDefault",
            background = R.color.ic_launcher_background,
            foreground = R.drawable.ic_launcher_foreground,
            enabledByDefault = true
        ),
        AppIconOption(
            "midnight", R.string.app_icon_midnight, "IconMidnight",
            R.color.ic_launcher_bg_midnight, R.drawable.ic_app_icon_midnight
        ),
        AppIconOption(
            "aurora", R.string.app_icon_aurora, "IconAurora",
            R.color.ic_launcher_bg_aurora, R.drawable.ic_app_icon_aurora
        ),
        AppIconOption(
            "sunset", R.string.app_icon_sunset, "IconSunset",
            R.color.ic_launcher_bg_sunset, R.drawable.ic_app_icon_sunset
        ),
        AppIconOption(
            "ocean", R.string.app_icon_ocean, "IconOcean",
            R.color.ic_launcher_bg_ocean, R.drawable.ic_app_icon_ocean
        ),
        AppIconOption(
            "mono", R.string.app_icon_mono, "IconMono",
            R.color.ic_launcher_bg_mono, R.drawable.ic_app_icon_mono
        ),
        AppIconOption(
            "rose", R.string.app_icon_rose, "IconRose",
            R.color.ic_launcher_bg_rose, R.drawable.ic_app_icon_rose
        ),
        AppIconOption(
            "gold", R.string.app_icon_gold, "IconGold",
            R.color.ic_launcher_bg_gold, R.drawable.ic_app_icon_gold
        ),
    )

    private fun componentOf(context: Context, option: AppIconOption) =
        ComponentName(context.packageName, ALIAS_PACKAGE + option.aliasName)

    /** The icon that is currently enabled, falls back to the default one */
    fun getCurrent(context: Context): AppIconOption {
        val pm = context.packageManager
        for (option in options) {
            val state = try {
                pm.getComponentEnabledSetting(componentOf(context, option))
            } catch (t: Throwable) {
                Log.e(TAG, "Unable to read icon state for ${option.id}", t)
                continue
            }
            val enabled = when (state) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED -> false
                else -> option.enabledByDefault
            }
            if (enabled) return option
        }
        return options.first()
    }

    /** Enables [option] and disables all other icons, returns false on failure */
    fun apply(context: Context, option: AppIconOption): Boolean {
        return try {
            val pm = context.packageManager
            // Enable the new one first so that there is always at least one launcher entry
            pm.setComponentEnabledSetting(
                componentOf(context, option),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            options.filter { it.id != option.id }.forEach {
                pm.setComponentEnabledSetting(
                    componentOf(context, it),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )
            }
            true
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to change app icon", t)
            false
        }
    }

    /** Shows a bottom sheet with all icons, tapping one applies it */
    fun showPicker(activity: Activity) {
        val binding = DialogAppIconPickerBinding.inflate(LayoutInflater.from(activity))
        val dialog = BottomSheetDialog(activity)
        dialog.setContentView(binding.root)

        val current = getCurrent(activity)
        binding.appIconRecycler.layoutManager = GridLayoutManager(activity, 4)
        binding.appIconRecycler.adapter = IconAdapter(options, current.id) { option ->
            if (option.id != current.id) {
                if (apply(activity, option)) {
                    showToast(activity, R.string.app_icon_changed, Toast.LENGTH_LONG)
                } else {
                    showToast(activity, R.string.error, Toast.LENGTH_SHORT)
                }
            }
            dialog.dismiss()
        }
        dialog.show()
    }

    private class IconAdapter(
        private val items: List<AppIconOption>,
        private val selectedId: String,
        private val onClick: (AppIconOption) -> Unit,
    ) : RecyclerView.Adapter<IconAdapter.Holder>() {

        class Holder(val binding: ItemAppIconBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
            Holder(ItemAppIconBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val item = items[position]
            val binding = holder.binding
            val context = binding.root.context
            val density = context.resources.displayMetrics.density
            val isSelected = item.id == selectedId

            binding.appIconBg.setImageDrawable(GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 16f * density
                setColor(ContextCompat.getColor(context, item.background))
                if (isSelected) {
                    setStroke((2.5f * density).toInt(), ContextCompat.getColor(context, R.color.white))
                }
            })
            binding.appIconImage.setImageResource(item.foreground)
            binding.appIconCheck.isVisible = isSelected
            binding.appIconLabel.setText(item.label)
            binding.root.setOnClickListener { onClick(item) }
        }
    }
}
